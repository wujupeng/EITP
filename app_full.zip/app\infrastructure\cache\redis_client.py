"""异步 Redis 客户端 - 承载 Token 撤销列表、暴力破解计数、Session 缓存。"""

from __future__ import annotations

from redis.asyncio import Redis, from_url
from structlog import get_logger

from app.config import get_settings

logger = get_logger(__name__)

_redis: Redis | None = None


async def get_redis() -> Redis:
    global _redis
    if _redis is None:
        settings = get_settings()
        _redis = from_url(
            settings.redis_url,
            max_connections=50,
            decode_responses=True,
            health_check_interval=30,
        )
        logger.info("redis_connected", url=settings.redis_url)
    return _redis


async def close_redis() -> None:
    global _redis
    if _redis is not None:
        await _redis.close()
        _redis = None
        logger.info("redis_closed")


async def redis_health_check() -> bool:
    try:
        r = await get_redis()
        return await r.ping()
    except Exception:
        return False