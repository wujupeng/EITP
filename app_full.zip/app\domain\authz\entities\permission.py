"""权限实体。"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from uuid import UUID, uuid4


@dataclass
class Permission:
    """权限实体 - 全局共享，不按租户隔离。"""

    id: UUID = field(default_factory=uuid4)
    code: str = ""
    name: str = ""
    module: str = ""
    description: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def create(cls, code: str, name: str, module: str, description: str = "") -> Permission:
        return cls(code=code, name=name, module=module, description=description)


BUILTIN_PERMISSIONS: list[dict[str, str]] = [
    {"code": "iam:user:read", "name": "查看用户", "module": "iam"},
    {"code": "iam:user:write", "name": "管理用户", "module": "iam"},
    {"code": "iam:role:read", "name": "查看角色", "module": "iam"},
    {"code": "iam:role:write", "name": "管理角色", "module": "iam"},
    {"code": "iam:audit:read", "name": "查看审计", "module": "iam"},
    {"code": "iam:datascope:write", "name": "管理数据权限", "module": "iam"},
    {"code": "tenant:hierarchy:read", "name": "查看层级", "module": "tenant"},
    {"code": "tenant:hierarchy:write", "name": "管理层级", "module": "tenant"},
    {"code": "tenant:config:read", "name": "查看配置", "module": "tenant"},
    {"code": "tenant:config:write", "name": "管理配置", "module": "tenant"},
    {"code": "platform:tenant:read", "name": "查看租户", "module": "platform"},
    {"code": "platform:tenant:write", "name": "管理租户", "module": "platform"},
]